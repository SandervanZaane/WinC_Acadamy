// opdracht 4 

// change backgroundcolor by clicking menu-items

let buttonGreen = document.getElementById("green");
let buttonRed = document.getElementById("red");
let buttonBlue = document.getElementById("blue");
let buttonYellow = document.getElementById("yellow");
let body = document.body;


buttonGreen.addEventListener("click", function() {
    body.classList.toggle("green-background");
});

buttonRed.addEventListener("click", function() {
    body.classList.toggle("red-background");
});

buttonBlue.addEventListener("click", function() {
    body.classList.toggle("blue-background");
});

buttonYellow.addEventListener("click", function() {
    body.classList.toggle("yellow-background");
});

// show menu toggle

let hamburger = document.getElementById("hamburger");

hamburger.addEventListener("click", function() {
    nav.classList.toggle("hidden");
})